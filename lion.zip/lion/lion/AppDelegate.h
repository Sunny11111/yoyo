//
//  AppDelegate.h
//  lion
//
//  Created by user on 15/12/5.
//  Copyright (c) 2015年 user. All rights reserved.
//  本人也是iOS开发者 一枚，酷爱技术 这是我的官方交流群  519797474

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

