//
//  AppDelegate.h
//  QTAttributeTextDemo
//
//  Created by Cass on 16/10/22.
//  Copyright © 2016年 Cass. All rights reserved.
//

#import <UIKit/UIKit.h>
//http://www.jianshu.com/p/a7f55e456539
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

