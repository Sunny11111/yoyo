//
//  ViewController.h
//  QTAttributeTextDemo
//
//  Created by Cass on 16/10/22.
//  Copyright © 2016年 Cass. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

