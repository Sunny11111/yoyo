
做好了autolayout你就完成了项目的90%
效果图如下:


![gif5新文件.gif](http://upload-images.jianshu.io/upload_images/913244-7c43bcb3b424421b.gif?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


ps:
本文采用UITableView+FDTemplateLayoutCell和UIView+FDCollapsibleConstraints
完成项目中加了图片浏览器, 用了YYKit的demo.
gif中完美展示了, 只有照片或者标题或者内容时上下间距都是8的效果, 实现简单,UITableView+FDTemplateLayoutCell也让上下滑动变得顺畅, 不需要再纠结计算于frame的麻烦
