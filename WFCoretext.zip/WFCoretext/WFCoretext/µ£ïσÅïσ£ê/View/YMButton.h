//
//  YMButton.h
//  WFCoretext
//
//  Created by 阿虎 on 14/11/4.
//  Copyright (c) 2014年 tigerwf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YMButton : UIButton

@property (nonatomic,strong) NSIndexPath * appendIndexPath;

@end
