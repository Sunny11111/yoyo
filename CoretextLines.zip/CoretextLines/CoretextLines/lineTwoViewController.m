//
//  lineTwoViewController.m
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import "lineTwoViewController.h"
#import "LWTextParser.h"
#import "Gallop.h"

#define kText @"近日😂😂😂adidas Originals😂为经典鞋款Stan Smith打造Primeknit版本，并带来全新的“OG”系列。简约的鞋身采用白色透气Primeknit针织材质制作，再将Stan Smith代表性的绿、红、深蓝三个元年色调融入到鞋舌和后跟点缀，最后搭载上米白色大底来保留其复古风味。据悉该鞋款将在今月登陆全球各大adidas Originals指定店舖。https://github.com/waynezxcv/Gallop <-"
@interface lineTwoViewController ()<LWAsyncDisplayViewDelegate>{
    LWTextStorage* openStorage;
    LWTextStorage* contentTextStorage ;
}
@property (nonatomic,strong) LWAsyncDisplayView* asyncView;

@end

@implementation lineTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    //创建LWAsyncDisplayView对象
    self.asyncView = [[LWAsyncDisplayView alloc] initWithFrame:CGRectMake(0.0f,
                                                                          64.0,
                                                                          SCREEN_WIDTH,
                                                                          SCREEN_HEIGHT - 64.0f)];
    self.asyncView.delegate = self;
    [self.view addSubview:self.asyncView];
    
    LWLayout* layout = [[LWLayout alloc] init];
    //正文内容模型 contentTextStorage
    contentTextStorage = [[LWTextStorage alloc] init];
    contentTextStorage.maxNumberOfLines = 5;//设置最大行数，超过则折叠
    contentTextStorage.text = kText;
    contentTextStorage.font = [UIFont fontWithName:@"Heiti SC" size:15.0f];
    contentTextStorage.textColor = RGB(40, 40, 40, 1);
    contentTextStorage.frame = CGRectMake(20,0,
                                          SCREEN_WIDTH - 40.0f,
                                          CGFLOAT_MAX);
    contentTextStorage.linespacing = 20;
    contentTextStorage.textBackgroundColor = [UIColor yellowColor];
    [layout addStorage:contentTextStorage];
    
    openStorage = [[LWTextStorage alloc] init];
    openStorage.font = [UIFont fontWithName:@"Heiti SC" size:15.0f];
    openStorage.textColor = RGB(40, 40, 40, 1);
    openStorage.frame = CGRectMake(20,
                                   contentTextStorage.bottom + 5.0f,
                                   200.0f,
                                   30.0f);
    openStorage.text = @"展开全文";
    [openStorage lw_addLinkWithData:@"open"
                              range:NSMakeRange(0, 4)
                          linkColor:RGB(113, 129, 161, 1)
                     highLightColor:RGB(0, 0, 0, 0.15f)];
    
    [layout addStorage:openStorage];
    self.asyncView.layout = layout;
}

//给文字添加点击事件后，若触发事件，会在这个代理方法中收到回调
- (void)lwAsyncDisplayView:(LWAsyncDisplayView *)asyncDisplayView
    didCilickedTextStorage:(LWTextStorage *)textStorage
                  linkdata:(id)data {
    NSLog(@"点击:%@",data);
    if ([data isKindOfClass:[NSString class]]) {
        if ([data isEqualToString:@"open"]) {
            contentTextStorage.maxNumberOfLines = 0;
            contentTextStorage.linespacing = 50;
            openStorage.text = @"收起全文";
            [openStorage lw_addLinkWithData:@"colse"
                                      range:NSMakeRange(0, 4)
                                  linkColor:RGB(113, 129, 161, 1)
                             highLightColor:RGB(0, 0, 0, 0.15f)];
        }else{
            openStorage.text = @"展开全文";
            contentTextStorage.linespacing = 20;
            contentTextStorage.maxNumberOfLines = 5;//设置最大行数，超过则折叠
            [openStorage lw_addLinkWithData:@"open"
                                      range:NSMakeRange(0, 4)
                                  linkColor:RGB(113, 129, 161, 1)
                             highLightColor:RGB(0, 0, 0, 0.15f)];
        }
        contentTextStorage.text = kText;
        
        contentTextStorage.frame = CGRectMake(20,0,
                                              SCREEN_WIDTH - 40.0f,
                                              CGFLOAT_MAX);
        openStorage.frame = CGRectMake(20,
                                       contentTextStorage.bottom + 5.0f,
                                       200.0f,
                                       30.0f);
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
