//
//  ViewController.m
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import "ViewController.h"
#import "lineOneViewController.h"
#import "lineTwoViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    
    NSArray *_dataSourceArr;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"文本展开收起";
    _dataSourceArr = @[@"类型1",@"类型2"];
    
    UITableView *mainTable = [[UITableView alloc] initWithFrame:CGRectMake(0,CGRectGetMaxY(self.navigationController.navigationBar.frame), self.view.frame.size.width, self.view.frame.size.height - 88)];
    mainTable.backgroundColor = [UIColor clearColor];
    // mainTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    mainTable.delegate = self;
    mainTable.dataSource = self;
    [self.view addSubview:mainTable];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  [_dataSourceArr count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"ILTableViewCell";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [_dataSourceArr objectAtIndex:indexPath.row];
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0){
        lineOneViewController * lineOneVC = [[lineOneViewController alloc] init];
        [self.navigationController pushViewController:lineOneVC animated:YES];
    }else if (indexPath.row == 1){
        lineTwoViewController * lineTwoVC = [lineTwoViewController new];
        [self.navigationController pushViewController:lineTwoVC animated:YES];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
