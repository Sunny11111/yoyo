//
//  lineTextView.h
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface lineTextView : UIView
@property (nonatomic,strong) NSAttributedString * attrEmotionString;
@property (nonatomic,strong) NSArray *emotionNames;//表情
@property (nonatomic,assign) BOOL isDraw;
@property (nonatomic,assign) BOOL isFold;//是否折叠
@property (nonatomic,strong) NSMutableArray *attributedData;//标记下特殊字符,比如手机号,网址
@property (nonatomic,strong) UIColor *textColor;

- (void)setOldString:(NSString *)oldString;

- (int)getTextLines;

- (float)getTextHeight;
@end
