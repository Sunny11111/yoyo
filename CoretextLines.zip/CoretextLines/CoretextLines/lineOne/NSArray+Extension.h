//
//  NSArray+Extension.h
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Extension)
- (NSArray *)offsetRangesInArrayBy:(NSUInteger)offset;
@end
