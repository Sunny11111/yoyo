//
//  Header.h
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#ifndef Header_h
#define Header_h
#define limitline 4

#endif /* Header_h */
