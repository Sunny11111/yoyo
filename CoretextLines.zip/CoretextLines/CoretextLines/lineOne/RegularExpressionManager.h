//
//  RegularExpressionManager.h
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RegularExpressionManager : NSObject
+ (NSArray *)itemIndexesWithPattern:(NSString *)pattern inString:(NSString *)findingString;
@end
