//
//  lineTextView.m
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import "lineTextView.h"
#import <CoreText/CoreText.h>
#import "RegularExpressionManager.h"
#import "NSArray+Extension.h"
#import "NSString+Extension.h"
#import "Header.h"

#define FontHeight                  15.0
#define ImageLeftPadding            2.0
#define ImageTopPadding             3.0
#define FontSize                    FontHeight
#define LineSpacing                 10.0
#define EmotionImageWidth           FontSize
#define EmotionItemPattern    @"\\[em:(\\d+):\\]" //表情
#define PlaceHolder @" "
#define AttributedImageNameKey      @"ImageName"



@interface  lineTextView (){
    NSString *_oldString;//未替换含有如[em:02:]的字符串
    NSString *_newString;//替换过含有如[em:02:]的字符串
    NSMutableArray *_selectionsViews;
    CTTypesetterRef typesetter;
    CTFontRef helvetica;
}
@end

@implementation lineTextView
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _isFold = YES;
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}
- (instancetype)init{
    self = [super init];
    if (self) {
        _isFold = YES;
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}
- (void)dealloc{
    if (typesetter != NULL) {
        CFRelease(typesetter);
    }
}
- (void)setTextColor:(UIColor *)textColor{
    _textColor = textColor;
}

- (void)setOldString:(NSString *)oldString{
    _oldString = oldString;
    [self cookEmotionString];
}
#pragma mark -
- (void)cookEmotionString{
    // 使用正则表达式查找特殊字符的位置
    NSArray *itemIndexes = [RegularExpressionManager itemIndexesWithPattern:
                            EmotionItemPattern inString:_oldString];
  //用PlaceHolder 替换掉[em:02:]这些
    NSString * newString = [_oldString replaceCharactersAtIndexes:itemIndexes
                                                          withString:PlaceHolder];
   _newString = newString;
    
    NSArray *names = nil;
    NSArray *newRanges = nil;
    names = [_oldString itemsForPattern:EmotionItemPattern captureGroupIndex:1];
    newRanges = [itemIndexes offsetRangesInArrayBy:[PlaceHolder length]];
    _emotionNames = names;
    _attrEmotionString = [self createAttributedEmotionStringWithRanges:newRanges
                                                             forString:_newString];
    typesetter = CTTypesetterCreateWithAttributedString((CFAttributedStringRef)
                                                        (_attrEmotionString));
    if (_isDraw == NO) {
        // CFRelease(typesetter);
        return;
    }
    [self setNeedsDisplay];
    
}

#pragma mark -
/**
 *  根据调整后的字符串，生成绘图时使用的 attribute string
 *
 *  @param ranges  占位符的位置数组
 *  @param aString 替换过含有如[em:02:]的字符串
 *
 *  @return 富文本String
 */
- (NSAttributedString *)createAttributedEmotionStringWithRanges:(NSArray *)ranges
                                                      forString:(NSString*)aString{
    
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:aString];
    helvetica = CTFontCreateWithName(CFSTR("Helvetica"),FontSize, NULL);
    [attrString addAttribute:(id)kCTFontAttributeName value: (id)CFBridgingRelease(helvetica) range:NSMakeRange(0,[attrString.string length])];
    
    [attrString addAttribute:(id)kCTForegroundColorAttributeName value:(id)([UIColor blackColor].CGColor) range:NSMakeRange(0,[attrString length])];
    
    if (_textColor == nil) {
        _textColor = [UIColor blueColor];
    }
    for (int i = 0; i < _attributedData.count; i ++) {
        
        NSString *str = [[[_attributedData objectAtIndex:i] allKeys] objectAtIndex:0];
        [attrString addAttribute:(id)kCTForegroundColorAttributeName value:(id)(_textColor.CGColor) range:NSRangeFromString(str)];
    }
    
    for(NSInteger i = 0; i < [ranges count]; i++){
        NSRange range = NSRangeFromString([ranges objectAtIndex:i]);
        NSString *emotionName = [self.emotionNames objectAtIndex:i];
        [attrString addAttribute:AttributedImageNameKey value:emotionName range:range];
        [attrString addAttribute:(NSString *)kCTRunDelegateAttributeName value:(__bridge id)newEmotionRunDelegate() range:range];
    }

    
    return attrString;
}

// 通过表情名获得表情的图片
- (UIImage *)getEmotionForKey:(NSString *)key{
    
    NSString *nameStr = [NSString stringWithFormat:@"%@.png",key];
    return [UIImage imageNamed:nameStr];
}

CTRunDelegateRef newEmotionRunDelegate(){
    
    static NSString *emotionRunName = @"emotionRunName";
    
    CTRunDelegateCallbacks imageCallbacks;
    imageCallbacks.version = kCTRunDelegateVersion1;
    imageCallbacks.dealloc = WFRunDelegateDeallocCallback;
    imageCallbacks.getAscent = WFRunDelegateGetAscentCallback;
    imageCallbacks.getDescent = WFRunDelegateGetDescentCallback;
    imageCallbacks.getWidth = WFRunDelegateGetWidthCallback;
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&imageCallbacks,
                                                       (__bridge void *)(emotionRunName));
    
    return runDelegate;
}

#pragma mark - Run delegate
void WFRunDelegateDeallocCallback( void* refCon ){
    // CFRelease(refCon);
}

CGFloat WFRunDelegateGetAscentCallback( void *refCon ){
    return FontHeight;
}

CGFloat WFRunDelegateGetDescentCallback(void *refCon){
    return 0.0;
}

CGFloat WFRunDelegateGetWidthCallback(void *refCon){
    // EmotionImageWidth + 2 * ImageLeftPadding
    return  19.0;
}

#pragma mark - 绘制
- (void)drawRect:(CGRect)rect{
    // 没有内容时取消本次绘制
    if (!typesetter)   return;
    
    CGFloat w = CGRectGetWidth(self.frame);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    UIGraphicsPushContext(context);
    
    // 翻转坐标系
    Flip_Context(context, FontHeight);
    
    CGFloat y = 0;
    CFIndex start = 0;
    NSInteger length = [_attrEmotionString length];
    int tempK = 0;
    while (start < length)
    {
        CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, w);
        CTLineRef line = CTTypesetterCreateLine(typesetter, CFRangeMake(start, count));
        CGContextSetTextPosition(context, 0, y);
        
        // 画字
        CTLineDraw(line, context);
        
        // 画表情
        Draw_Emoji_For_Line(context, line, self, CGPointMake(0, y));
        
        start += count;
        y -= FontSize + LineSpacing;
        CFRelease(line);
        tempK ++;
        if (tempK == limitline) {
            

        }
        
    }
    
    UIGraphicsPopContext();
}

// 翻转坐标系
static inline
void Flip_Context(CGContextRef context, CGFloat offset) // offset为字体的高度
{
    CGContextScaleCTM(context, 1, -1);
    CGContextTranslateCTM(context, 0, -offset);
}

// 生成每个表情的 frame 坐标
static inline
CGPoint Emoji_Origin_For_Line(CTLineRef line, CGPoint lineOrigin, CTRunRef run)
{
    CGFloat x = lineOrigin.x + CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL) + ImageLeftPadding;
    CGFloat y = lineOrigin.y - ImageTopPadding;
    return CGPointMake(x, y);
}


// 绘制每行中的表情
void Draw_Emoji_For_Line(CGContextRef context, CTLineRef line, id owner, CGPoint lineOrigin)
{
    CFArrayRef runs = CTLineGetGlyphRuns(line);
    
    // 统计有多少个run
    NSUInteger count = CFArrayGetCount(runs);
    
    // 遍历查找表情run
    for(NSInteger i = 0; i < count; i++){
        
        CTRunRef aRun = CFArrayGetValueAtIndex(runs, i);
        CFDictionaryRef attributes = CTRunGetAttributes(aRun);
        NSString *emojiName = (NSString *)CFDictionaryGetValue(attributes, AttributedImageNameKey);
        if (emojiName){
            // 画表情
            CGRect imageRect = CGRectZero;
            imageRect.origin = Emoji_Origin_For_Line(line, lineOrigin, aRun);
            imageRect.size = CGSizeMake(EmotionImageWidth, EmotionImageWidth);
            CGImageRef img = [[owner getEmotionForKey:emojiName] CGImage];
            CGContextDrawImage(context, imageRect, img);
        }
    }
}


- (float)getTextHeight{
    CGFloat w = CGRectGetWidth(self.frame);
    CGFloat y = 0;
    CFIndex start = 0;
    NSInteger length = [_attrEmotionString length];
    int tempK = 0;
    while (start < length){
        CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, w);
        CTLineRef line = CTTypesetterCreateLine(typesetter, CFRangeMake(start, count));
        start += count;
        y -= FontSize + LineSpacing;
        CFRelease(line);
        tempK++;
        if (tempK == limitline  && _isFold == YES) {
            break;
        }
    }
    return -y;
}
#pragma mark - 获得行数
- (int)getTextLines{
    int textlines = 0;
    CGFloat w = CGRectGetWidth(self.frame);
    CGFloat y = 0;
    CFIndex start = 0;
    NSInteger length = [_attrEmotionString length];
    while (start < length){
        CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, w);
        CTLineRef line = CTTypesetterCreateLine(typesetter, CFRangeMake(start, count));
        start += count;
        y -= FontSize + LineSpacing;
        CFRelease(line);
        
        textlines ++;
    }
    return textlines;
}










@end
