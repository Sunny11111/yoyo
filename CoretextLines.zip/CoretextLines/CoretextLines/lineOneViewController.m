//
//  lineOneViewController.m
//  CoretextLines
//
//  Created by Kun Yang on 2017/12/31.
//  Copyright © 2017年 Kun Yang. All rights reserved.
//

#import "lineOneViewController.h"
#import "lineTextView.h"
#import "Header.h"

#define kShuoshuoText1 @"[em:02:]驱魔人“你可知道邪恶深藏于你心深处，但我会始终在你的[em:02:]左右，握着我的手，我会让你看到神迹，抱紧信仰，除此你一无所有！驱魔人 “你可知道邪恶深藏于你心深处，但我会始终在你的[em:02:]左右，握着我的手，我会让你看到神迹，抱紧信仰，除此你一无所有！”"
#define kShuoshuoText2 @"高德开放平台提供2D，3D，卫星多种地图形式供开发者选择，无论基于哪种平台，都可以通过高德开放平台提供的API和SDK轻松的完成地图的构建工作。同时我们还提供强大的地图再开发能力，全面的地图数据支持，离线在线两种使用方式，多种地图交互模式，满足各个场景下对地图的需求"

#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height
@interface lineOneViewController (){
    UIButton *foldBtn;
    lineTextView * textView;
    CGFloat height;
    CGFloat laterHeight;
}
@end

@implementation lineOneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    textView = [[lineTextView alloc] initWithFrame:CGRectMake(20,100,ScreenW - 40,0)];
    textView.isFold = YES;//是否折叠
    textView.isDraw = YES;
    textView.backgroundColor = [UIColor yellowColor];
    [textView setOldString:kShuoshuoText1];
   
    textView.frame = CGRectMake(20,100,ScreenW - 40,[textView getTextHeight]);
    [self.view addSubview:textView];
    
    foldBtn = [UIButton buttonWithType:0];
    [foldBtn setTitle:@"展开" forState:0];
    foldBtn.backgroundColor = [UIColor clearColor];
    foldBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [foldBtn setTitleColor:[UIColor grayColor] forState:0];
    [foldBtn addTarget:self action:@selector(foldText:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:foldBtn];
    foldBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    foldBtn.frame = CGRectMake(20,CGRectGetMaxY(textView.frame),50,20);
}
- (void)foldText:(UIButton *)sender{
    textView.isFold = ! textView.isFold;//是否折叠
    textView.backgroundColor = [UIColor yellowColor];
    [textView setOldString:kShuoshuoText2];
    textView.frame = CGRectMake(20,100,ScreenW - 40,[textView getTextHeight]);
    foldBtn.frame = CGRectMake(20,CGRectGetMaxY(textView.frame),50,20);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
