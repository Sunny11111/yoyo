//
//  AppDelegate.h
//  朋友圈高性能
//
//  Created by Binbin Mu on 2017/10/27.
//  Copyright © 2017年 Binbin Mu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

