//
//  PenyouquanModal.h
//  朋友圈高性能
//
//  Created by Binbin Mu on 2017/10/30.
//  Copyright © 2017年 Binbin Mu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PenyouquanModal : NSObject
@property(nonatomic ,strong)NSString *iconName;
@property(nonatomic ,strong)NSString *iconImage;
@property(nonatomic ,strong)NSString *TitleName;
@property(nonatomic ,strong)NSArray *images;
@end
