//
//  NTViewController.h
//  tableViewDemo 仿qq空间列表
//
//  Created by MD101 on 14-10-10.
//  Copyright (c) 2014年 NT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTViewController : UIViewController

@end
