//
//  NTViewController.m
//  tableViewDemo 仿qq空间列表
//
//  Created by MD101 on 14-10-10.
//  Copyright (c) 2014年 NT. All rights reserved.
//

#import "NTViewController.h"
#import "NTStatus.h"
#import "NTStatusTableViewCell.h"

@interface NTViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>{
    
    UITableView * _tableView;
    NSMutableArray * _status;
    NSMutableArray *_statusCells;//存储cell，用于计算高度
}

@end

@implementation NTViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
    
    [self initData];
	// Do any additional setup after loading the view, typically from a nib.
}

#pragma mark 加载数据
- (void)initData{
    NSString * path = [[NSBundle mainBundle]pathForResource:@"statusinfo" ofType:@"plist"];
    NSArray * array = [NSArray arrayWithContentsOfFile:path];
    _status = [NSMutableArray array];
    _statusCells = [NSMutableArray array];
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
    [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [_status addObject:[NTStatus statusWithDictionary:obj]];
        
         NTStatusTableViewCell * cell = [[NTStatusTableViewCell alloc]init];
        [_statusCells addObject:cell];
    }];
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
}

#pragma mark - 数据源方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _status.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString * identifier = @"Cell";
    NTStatusTableViewCell * cell;
    cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[NTStatusTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NTStatus * status = _status[indexPath.row];
    cell.status = status;
    return cell;
}

#pragma mark - 代理方法
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
#pragma mark 重新设置行高
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NTStatusTableViewCell * cell = _statusCells[indexPath.row];
    cell.status = _status[indexPath.row];
    return cell.height;
}
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
#pragma mark 重写状态样式方法
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
