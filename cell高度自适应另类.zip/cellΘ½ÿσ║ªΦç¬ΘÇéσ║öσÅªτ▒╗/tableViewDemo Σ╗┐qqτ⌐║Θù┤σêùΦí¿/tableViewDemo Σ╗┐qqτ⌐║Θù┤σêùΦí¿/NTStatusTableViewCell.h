//
//  NTStatusTableViewCell.h
//  TableView
//
//  Created by MD101 on 14-10-10.
//  Copyright (c) 2014年 NT. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NTStatus;

@interface NTStatusTableViewCell : UITableViewCell
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
#pragma mark 微博对象
@property (nonatomic ,strong) NTStatus * status;

#pragma mark 单元格高度
@property (nonatomic ,assign) CGFloat height;
//🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟🐟
@end
